/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package revision;

/**
 *
 * @author user
 */
public class Revision {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Home hm = new Home();
        hm.show();
    }
    
}
