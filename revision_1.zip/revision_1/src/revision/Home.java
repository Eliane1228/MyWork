package revision;
import java.sql.*;
import java.util.*;
import java.util.logging.*;
import javax.swing.table.DefaultTableModel;
public class Home extends javax.swing.JFrame {
    Connection conne;
    Statement st;
    PreparedStatement ps;
    ResultSet rs;
    public Home() {
        initComponents();
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conne = DriverManager.getConnection("jdbc:mysql://localhost:3306/rev","root","");
            st = conne.createStatement();
            String sel = "SELECT * FROM stud";
            rs = st.executeQuery(sel);
            
            while(rs.next()){
            DefaultTableModel dtm = (DefaultTableModel)tb.getModel();
            Object obj[] = {rs.getString("Id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"),rs.getString("clas")};
            dtm.addRow(obj);
            }
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        fname = new javax.swing.JTextField();
        lname = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        ages = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        clas = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        insertb = new javax.swing.JButton();
        updb = new javax.swing.JButton();
        dltb = new javax.swing.JButton();
        searchf = new javax.swing.JTextField();
        searchb = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tb = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel2.setFont(new java.awt.Font("Verdana", 3, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(153, 153, 0));
        jLabel2.setText("Registration Form");

        jLabel1.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel1.setText("Firstname : ");

        fname.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        lname.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel3.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel3.setText("Lastname : ");

        ages.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel4.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel4.setText("Age : ");

        clas.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        jLabel5.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        jLabel5.setText("Class : ");

        insertb.setBackground(new java.awt.Color(153, 153, 0));
        insertb.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        insertb.setForeground(new java.awt.Color(255, 255, 255));
        insertb.setText("Insert");
        insertb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertbActionPerformed(evt);
            }
        });

        updb.setBackground(new java.awt.Color(0, 153, 204));
        updb.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        updb.setForeground(new java.awt.Color(255, 255, 255));
        updb.setText("Update");
        updb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updbActionPerformed(evt);
            }
        });

        dltb.setBackground(new java.awt.Color(255, 51, 51));
        dltb.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        dltb.setForeground(new java.awt.Color(255, 255, 255));
        dltb.setText("Delete");
        dltb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dltbActionPerformed(evt);
            }
        });

        searchf.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        searchb.setBackground(new java.awt.Color(0, 153, 204));
        searchb.setFont(new java.awt.Font("Verdana", 1, 12)); // NOI18N
        searchb.setForeground(new java.awt.Color(255, 255, 255));
        searchb.setText("Search");
        searchb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchbActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(163, 163, 163)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 217, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addGap(102, 102, 102)
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addComponent(searchf, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(searchb))
                                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(lname, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(ages, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel4Layout.createSequentialGroup()
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addGap(102, 102, 102)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                                    .addContainerGap()
                                    .addComponent(insertb)
                                    .addGap(49, 49, 49)))
                            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(jPanel4Layout.createSequentialGroup()
                                    .addGap(24, 24, 24)
                                    .addComponent(updb)
                                    .addGap(59, 59, 59)
                                    .addComponent(dltb))
                                .addComponent(clas, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(83, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(jLabel2)
                .addGap(31, 31, 31)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(searchf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(searchb))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(lname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(ages, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(clas, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dltb)
                    .addComponent(updb)
                    .addComponent(insertb))
                .addContainerGap(103, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Register", jPanel4);

        tb.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "Firstname", "Lastname", "Age", "Class"
            }
        ));
        jScrollPane1.setViewportView(tb);

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 501, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 198, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(235, 235, 235))
        );

        jTabbedPane2.addTab("List", jPanel5);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jTabbedPane2)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void insertbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertbActionPerformed
        try {
            String fnames = fname.getText();
            String lnames = lname.getText();
            int age = Integer.parseInt(ages.getText());
            String clase = clas.getText();
            String sql = "INSERT INTO stud(fname,lname,age,clas) VALUES('"+fnames+"','"+lnames+"','"+age+"','"+clase+"')";
            st = conne.createStatement();
            st.executeUpdate(sql);
            DefaultTableModel dtm = (DefaultTableModel)tb.getModel();
            dtm.setRowCount(0);
            String sel = "SELECT * FROM stud";
            rs = st.executeQuery(sel);
            fname.setText(null);
            lname.setText(null);
            ages.setText(null);
            clas.setText(null);
            searchf.setText(null);
            while(rs.next()){
            Object obj[] = {rs.getString("Id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"),rs.getString("clas")};
            dtm.addRow(obj);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_insertbActionPerformed

    private void updbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updbActionPerformed
         try {
            String id = searchf.getText();
            String fnames = fname.getText();
            String lnames = lname.getText();
            int age = Integer.parseInt(ages.getText());
            String clase = clas.getText();
            ps = conne.prepareStatement("UPDATE stud SET fname=?,lname=?,age=?,clas=? WHERE Id ='"+id+"'");
            ps.setString(1, fnames);
            ps.setString(2, lnames);
            ps.setInt(3, age);
            ps.setString(4, clase);
            ps.executeUpdate();
            fname.setText(null);
            lname.setText(null);
            ages.setText(null);
            clas.setText(null);
            searchf.setText(null);
            st = conne.createStatement();
            DefaultTableModel dtm = (DefaultTableModel)tb.getModel();
            dtm.setRowCount(0);
            String sel = "SELECT * FROM stud";
            rs = st.executeQuery(sel);
            
            while(rs.next()){
            
            Object obj[] = {rs.getString("Id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"),rs.getString("clas")};
            
            dtm.addRow(obj);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_updbActionPerformed

    private void dltbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dltbActionPerformed
        try {
            String id = searchf.getText();
            ps = conne.prepareStatement("DELETE FROM stud WHERE Id ='"+id+"'");
            ps.executeUpdate();
            fname.setText(null);
            lname.setText(null);
            ages.setText(null);
            clas.setText(null);
            searchf.setText(null);
            st = conne.createStatement();
            DefaultTableModel dtm = (DefaultTableModel)tb.getModel();
            dtm.setRowCount(0);
            String sel = "SELECT * FROM stud";
            rs = st.executeQuery(sel);
            
            while(rs.next()){
            
            Object obj[] = {rs.getString("Id"),rs.getString("fname"),rs.getString("lname"),rs.getInt("age"),rs.getString("clas")};
            
            dtm.addRow(obj);
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_dltbActionPerformed

    private void searchbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_searchbActionPerformed
            try{
            String id = searchf.getText();
            st = conne.createStatement();
            String sel = "SELECT * FROM stud WHERE Id = '"+id+"'";
            rs = st.executeQuery(sel);
            
            if(rs.next()){
            String fnam = rs.getString("fname");
            String lnam = rs.getString("lname");
            int ag = rs.getInt("age");
            String cla = rs.getString("clas");
            fname.setText(fnam);
            lname.setText(lnam);
            ages.setText(String.valueOf(ag));
            clas.setText(cla);
            
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }//GEN-LAST:event_searchbActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Home.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Home().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField ages;
    private javax.swing.JTextField clas;
    private javax.swing.JButton dltb;
    private javax.swing.JTextField fname;
    private javax.swing.JButton insertb;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JTextField lname;
    private javax.swing.JButton searchb;
    private javax.swing.JTextField searchf;
    private javax.swing.JTable tb;
    private javax.swing.JButton updb;
    // End of variables declaration//GEN-END:variables
}
