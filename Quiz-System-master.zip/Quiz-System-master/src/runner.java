import java.sql.SQLException;

public class runner {
    public static void main(String args[]) throws SQLException {
        login login = new login();
        login.loginView();
    }
}